import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Engine } from '../src/core/engine';
import { RULES, WEAPON_IDS, PASSIVE_IDS, ENEMIES, weaponStats, xpForLevel, spawnInterval } from '../src/core/config';
import { choices, initialBuild } from '../src/core/upgrades';
import { Random } from '../src/core/random';
import { SpatialHash } from '../src/core/spatial';
import { decodeSave, freshSave, readSave, writeSave } from '../src/core/storage';

test('normalized movement, arena bounds and frame delta guard',()=>{
  const e=new Engine(1),x=e.player.x,y=e.player.y;e.step(.05,{x:1,y:1});
  assert.ok(Math.abs(Math.hypot(e.player.x-x,e.player.y-y)-RULES.playerSpeed*.05)<.001);
  e.player.x=3199;e.player.y=2399;e.step(.05,{x:1,y:1});assert.equal(e.player.x,3168);assert.equal(e.player.y,2368);
  const time=e.time;e.step(NaN,{x:1,y:1});assert.equal(e.time,time);
});
test('contact hurts, invulnerability prevents repeated damage, death is terminal',()=>{
  const e=new Engine(2);e.spawn('hollow',e.player.x,e.player.y);e.step(.016,{x:0,y:0});assert.ok(e.player.hp<110);
  const hp=e.player.hp;e.hurt(100);assert.equal(e.player.hp,hp);
  e.player.invulnerable=0;e.hurt(999);assert.equal(e.status,'dead');assert.equal(e.player.hp,0);const t=e.time;e.step(.05,{x:1,y:0});assert.equal(e.time,t);
});
test('pause freezes everything, resume advances, dash grants immunity and obeys cooldown',()=>{
  const e=new Engine(3);e.pause();const x=e.player.x;e.step(.05,{x:1,y:0,dash:true});assert.equal(e.time,0);assert.equal(e.player.x,x);
  e.pause();e.step(.05,{x:1,y:0,dash:true});assert.ok(e.player.x-x>20);assert.ok(e.player.invulnerable>0);const hp=e.player.hp;e.hurt(999);assert.equal(e.player.hp,hp);
  const cd=e.player.dashCooldown;e.step(.05,{x:1,y:0,dash:true});assert.ok(e.player.dashCooldown<cd);
});
test('level-up has three distinct offers, selection changes build and queued XP is retained',()=>{
  const e=new Engine(4);e.addXp(xpForLevel(1)+xpForLevel(2));assert.equal(e.status,'upgrade');assert.equal(e.level,2);assert.equal(e.offers.length,3);assert.equal(new Set(e.offers.map(o=>o.id)).size,3);
  assert.equal(e.selectUpgrade(7),false);assert.equal(e.selectUpgrade(0),true);assert.equal(e.level,3);assert.equal(e.status,'upgrade');e.selectUpgrade(0);assert.equal(e.status,'playing');
});
for(const weapon of WEAPON_IDS)test(`${weapon}: real combat damages targets and level 6 increases potency`,()=>{
  const e=new Engine(77);e.build.weapons={blade:0,orb:0,fire:0,frost:0,lightning:0};e.build.weapons[weapon]=1;
  e.player.invulnerable=1000;
  for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const target=e.spawn('brute',e.player.x+Math.cos(a)*80,e.player.y+Math.sin(a)*80)!;target.hp=10000;target.maxHp=10000;target.speed=0;}
  let slowed=false;for(let i=0;i<300;i++){e.step(1/60,{x:0,y:0});slowed ||= e.enemies.some(x=>x.slow>0);}assert.ok(e.weaponDamage[weapon]>0,`${weapon} never dealt damage`);
  const a=weaponStats(weapon,1),b=weaponStats(weapon,6);assert.ok(b.damage>a.damage);assert.ok(b.cooldown<a.cooldown);assert.ok(b.range>a.range);
  if(weapon==='frost')assert.ok(slowed);
});
test('every passive changes its promised stat; rarity bonus heals and caps',()=>{
  const e=new Engine(4);e.player.hp=30;
  const before={damage:e.damageMultiplier,speed:e.playerSpeed,haste:e.attackSpeed,crit:e.criticalChance,range:e.rangeMultiplier,pickup:e.pickupRadius,hp:e.player.maxHp};
  for(const id of PASSIVE_IDS)e.applyUpgrade({id,rarity:'common',bonus:0});
  assert.ok(e.damageMultiplier>before.damage&&e.playerSpeed>before.speed&&e.attackSpeed>before.haste&&e.criticalChance>before.crit&&e.rangeMultiplier>before.range&&e.pickupRadius>before.pickup);
  assert.equal(e.player.maxHp,before.hp+20);assert.equal(e.player.hp,50);e.step(.05,{x:0,y:0});assert.ok(e.player.hp>50);
  e.applyUpgrade({id:'blade',rarity:'epic',bonus:18});assert.ok(e.player.hp>68);e.player.hp=e.player.maxHp;e.applyUpgrade({id:'blade',rarity:'epic',bonus:18});assert.equal(e.player.hp,e.player.maxHp);
});
test('frost slows, lightning jumps, fire pierces at higher levels, orbit positions move',()=>{
  const e=new Engine(6);e.enemies=[];e.build.weapons={blade:0,orb:6,fire:6,frost:6,lightning:6};
  for(let i=0;i<12;i++){const enemy=e.spawn('brute',e.player.x+50+i*10,e.player.y)!;enemy.hp=10000;enemy.maxHp=10000;enemy.speed=0;}
  e.player.invulnerable=100;const orbit=e.orbPositions();e.cooldowns={blade:0,orb:0,fire:0,frost:0,lightning:0};e.step(.016,{x:0,y:0});
  assert.equal(e.orbPositions().length,4);assert.notEqual(e.orbPositions()[0].x,orbit[0].x);assert.ok(e.enemies[0].slow>0);
  assert.ok(e.events.some(v=>v.type==='lightning'&&v.points!.length>3));assert.ok(e.projectiles.some(p=>p.pierce===1));
});
test('enemy kinds unlock on schedule; ranged, elite and boss attacks actually execute',()=>{
  assert.equal(Object.keys(ENEMIES).length,6);assert.ok(spawnInterval(600)<spawnInterval(0));
  const e=new Engine(8);for(let i=0;i<100;i++)e.spawn();assert.ok(e.enemies.every(x=>x.kind==='hollow'));
  e.enemies=[];e.time=400;const seer=e.spawn('seer',e.player.x+300,e.player.y)!;seer.attack=0;const elite=e.spawn('reaper',e.player.x+200,e.player.y)!;elite.attack=0;
  e.step(.016,{x:0,y:0});assert.ok(e.projectiles.some(p=>p.enemy));assert.ok(elite.charge>0);
  e.time=660;e.step(.016,{x:0,y:0});assert.ok(e.boss);e.boss!.attack=0;e.step(.016,{x:0,y:0});assert.ok(e.warnings.length>=2);assert.ok(e.projectiles.filter(p=>p.enemy).length>=12);
});
test('boss death wins a run and restart creates a clean engine',()=>{
  const e=new Engine(9);e.time=660;e.step(.016,{x:0,y:0});e.hit(e.boss!,999999,'blade');e.step(.016,{x:0,y:0});assert.equal(e.status,'won');
  const next=new Engine(9);assert.equal(next.time,0);assert.equal(next.level,1);assert.equal(next.kills,0);assert.equal(next.bossSpawned,false);assert.equal(next.build.weapons.orb,0);
});
test('XP and healing are collected, loot cap preserves XP and pool limits are respected',()=>{
  const e=new Engine(11);e.player.hp=50;e.drop(e.player.x,e.player.y,12,true);e.drop(e.player.x,e.player.y,3,false);e.step(.016,{x:0,y:0});assert.equal(e.player.hp,62);assert.equal(e.xp,3);assert.equal(e.loot.length,0);
  for(let i=0;i<600;i++){e.drop(300+i,300,2,false);e.spawn('hollow',200,200);}
  assert.equal(e.loot.length,RULES.lootCap);assert.equal(e.loot.reduce((s,l)=>s+l.value,0),1200);assert.equal(e.enemies.length,RULES.enemyCap);
});
test('spatial queries include every relevant object across cell boundaries',()=>{
  const grid=new SpatialHash<{x:number;y:number}>();const points=[{x:99,y:99},{x:101,y:101},{x:200,y:200}];grid.rebuild(points);assert.equal(grid.query(100,100,3).length,2);grid.rebuild([]);assert.equal(grid.query(100,100,1000).length,0);
});
test('random rolls are reproducible and capped upgrades stop appearing',()=>{
  const a=new Random(19),b=new Random(19);for(let i=0;i<100;i++)assert.equal(a.next(),b.next());
  const build=initialBuild();build.weapons.blade=6;for(let i=0;i<100;i++)assert.ok(choices(build,a).every(o=>o.id!=='blade'));
});
test('corrupt, missing, hostile and unavailable saves fall back safely',()=>{
  for(const bad of [null,'{bad','null','[]','{"version":2}','{"version":1,"settings":{"volume":"loud"},"stats":{"kills":-5}}'])assert.equal(decodeSave(bad).stats.kills,0);
  const save=freshSave();save.stats.kills=123;save.settings.volume=.8;assert.deepEqual(decodeSave(JSON.stringify(save)),save);
  assert.doesNotThrow(()=>readSave());assert.equal(writeSave(save),false);
});
test('eclipse cycles end and start at documented boundaries',()=>{
  const e=new Engine(12);e.time=69;assert.equal(e.eclipse,false);e.time=70;assert.equal(e.eclipse,true);e.time=89.99;assert.equal(e.eclipse,true);e.time=90;assert.equal(e.eclipse,false);
});
test('maxed builds retain three useful recovery choices without false upgrade promises',()=>{
  const e=new Engine(42);for(const id of WEAPON_IDS)e.build.weapons[id]=6;for(const id of PASSIVE_IDS)e.build.passives[id]=5;
  const offered=choices(e.build,e.rng);assert.equal(offered.length,3);assert.equal(new Set(offered.map(o=>o.id)).size,3);assert.ok(offered.every(o=>o.recovery));
  e.player.hp=10;e.player.dashCooldown=7;const max=e.player.maxHp;for(const offer of offered)e.applyUpgrade(offer);
  assert.equal(e.player.maxHp,max+10);assert.equal(e.player.dashCooldown,0);assert.equal(e.player.hp,75);
});
test('boss entrance clears hostile projectiles and servants without granting kills',()=>{
  const e=new Engine(88);e.time=659.99;e.spawn('seer',e.player.x+300,e.player.y);const kills=e.kills;e.step(.02,{x:0,y:0});assert.ok(e.boss);assert.equal(e.enemies.length,1);assert.equal(e.kills,kills);assert.ok(e.projectiles.every(p=>!p.enemy));
});
