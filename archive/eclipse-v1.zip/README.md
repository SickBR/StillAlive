# ECLIPSE SURVIVOR

Ein eigenständiges Dark-Fantasy-Survival-Roguelite für den Desktop-Browser. Ein Ritter, ein zerbrochenes Kloster und eine wiederkehrende Finsternis. TypeScript, Phaser 3.90 und Vite; kein Backend, keine Konten, keine externen Laufzeitdienste.

## Start

Voraussetzung: **Node.js ab 22.12 mit npm**, ein aktueller Desktop-Browser und eine Tastatur. Internet wird einmalig zum Installieren der Bibliotheken benötigt. Die fertige Anwendung lädt ausschließlich lokale Dateien.

```sh
npm install
npm run dev
```

Anschließend **http://127.0.0.1:5173/** öffnen. Falls der Port belegt ist, zeigt Vite den gewählten Ersatzport an.

```sh
npm run build
npm run preview
```

Der Produktionsbuild liegt in `dist/`, die Vorschau standardmäßig unter **http://127.0.0.1:4173/**. `dist/` kann auf einem gewöhnlichen statischen Webserver liegen. Nicht per `file://` öffnen. Ein Service Worker und ein Offline-Installer sind nicht enthalten.

## Spielen

| Eingabe | Aktion |
| --- | --- |
| WASD / Pfeiltasten | Bewegung; diagonale Geschwindigkeit ist normalisiert |
| Leertaste | Schattenschritt in die Bewegungsrichtung; 8 Sekunden Abklingzeit |
| Escape / P | Pause / Fortsetzen |
| 1 / 2 / 3 oder Maus | Upgrade wählen |

Angriffe erfolgen automatisch. Grüne Kristalle geben XP; Herzen heilen. Ein Levelaufstieg heilt zusätzlich 5 LP und hält die Simulation für die Wahl aus drei Karten an. Seltene Karten heilen zusätzlich 8 LP, epische 18 LP. Waffen erreichen Stufe 6, passive Fähigkeiten Stufe 5. Vollständig entwickelte Builds erhalten weitere klar beschriebene Erholungsangebote.

**Schattenschritt:** Ein kurzer unverwundbarer Sprint; eine Schadenswelle trifft am Ausgangspunkt. **Finsternis:** In den letzten 20 Sekunden jedes 90-Sekunden-Zyklus verursacht die Schattenklinge 35 % und der Schattenschritt 50 % mehr Schaden, während Gegner 15 % schneller werden.

**Finale:** Nach 11 Minuten verschlingt der Entthronte seine verbliebenen Diener und erscheint nahe dem Spieler. Für diese entfernten Gegner gibt es keine Kills oder XP. Der Nachschub wird reduziert. Ein goldener Richtungspfeil weist zum Boss, wenn er weiter entfernt ist. Bei halbem Leben oder ab Minute 12 wechselt er in seine stärkere Phase. **Der Sieg erfordert seinen Tod**, das Erreichen von Minute 12 allein genügt nicht. Typische erfolgreiche automatisierte Läufe liegen zwischen 11:21 und 13:22 Minuten. Es gibt kein hartes Zeitlimit.

## Implementierter Umfang

- Shadow Knight mit Idle-, Lauf-, Treffer- und vierstufiger Todesanimation, Richtungswechsel, Schatten und Spezialfähigkeit.
- Shadow Blade (Nahkampfbogen), Arcane Orb (umlaufende Kontaktwaffen), Firebolt (lenkende, später durchdringende Projektile), Frost Nova (Fläche und Verlangsamung), Lightning Chain (springende Blitze).
- Sieben passive Upgrades: Schaden, Angriffstempo, Bewegung, maximale LP, Regeneration, kritische Treffer, Reichweite/Sammelradius.
- Fünf Gegnerarten: Aschenpilger, Rissläufer, Gruftwächter, Leerseher und Rissritter. Unterschiedliche Werte, Silhouetten, Fernkampfdistanz und angekündigte Sprintattacken.
- Ein Boss mit zwei Phasen, radialen Projektilmustern und vorab markierten Flächeneinschlägen.
- Zunehmender Gegnernachschub, XP, Loot, begrenzte Heil-Drops, Levelwahl, Pause, automatische Pause bei Fokusverlust, Sieg, Niederlage und saubere Neustarts.
- Hauptmenü, Steuerungsübersicht, Einstellungen, Chronik, Lebens-/XP-Balken, Arsenal, Timer und Bossanzeige.
- 29 eigene lokale PNG-Dateien, Trefferblitze, Schadenszahlen, Zaubereffekte, dezente Beleuchtung und Bildschirmerschütterung.
- Eigene synthetische Klänge und ein zurückhaltender Grundton über Web Audio; Lautstärke bis stumm einstellbar.
- Validierte, versionierte LocalStorage-Daten für Einstellungen, Bestzeiten, Level, Kills, Siege und abgeschlossene/aufgegebene Durchläufe. Fehlender oder beschädigter Speicher blockiert den Spielstart nicht.

## Aufbau

```text
src/core/config.ts       Zentrale Regeln, Waffen-/Gegnerwerte, XP und Spawnkurve
src/core/engine.ts       Renderunabhängige Simulation und Zustandsübergänge
src/core/upgrades.ts     Upgrade-Pool, Seltenheiten und Beschreibungen
src/core/spatial.ts      Räumliches Raster für Nachbarschaft und Treffer
src/core/storage.ts      Validierte Speicherung mit sicheren Fallbacks
src/render/GameScene.ts  Phaser, Tastatureingaben, Kamera, Objektpools, Effekte
src/ui.ts                DOM-Menüs, HUD und Dialoge
src/audio.ts             Eigene Web-Audio-Klänge mit begrenzter Stimmenrate
src/main.ts              Verbindung von Simulation, Darstellung, UI und Speicher
public/assets/          Fertige, lokal geladene PNG-Texturen
scripts/                Asset-Erzeugung, Simulation und Browserprüfung
tests/                  Automatisierte Tests der echten Spielsimulation
reports/                Prüfergebnisse und Browser-Screenshots
```

Die Simulation erhält Sekundenwerte und begrenzt einzelne Zeitschritte auf 50 ms. Menüpausen zählen nicht zur Überlebenszeit. Der Renderer verwendet wiederverwendete Bilder und Textobjekte; Objektzahlen, Geschosse, Loot, Effekte und Schadenszahlen sind begrenzt. Spatial Hashing beschränkt die meisten Nahbereichsabfragen. Für neue Durchläufe wird die Simulation ersetzt, nicht eine zusätzliche Phaser-Szene oder ein weiterer Event-Listener angelegt.

## Tests

```sh
npm test
npm run simulate
npm run build
```

Für die automatisierte Browserprüfung zuerst `npm run dev` starten. Danach in einem zweiten Terminal:

```sh
npx playwright install chromium
npm run test:browser
```

Unter Windows wird eine bereits installierte Playwright-Chromium-Version automatisch gesucht. Alternativ kann `CHROME_PATH` einen Chromium-Pfad angeben. Die Tests verwenden Headless Chromium und keine externen Webseiten. Die Browserprüfung verlangt Port 5173; `BASE_URL` kann bei Bedarf eine andere lokale Entwicklungsadresse angeben.

`npm test` prüft 20 Fälle inklusive echter Waffenangriffe, aller passiven Effekte, Kontakt-/Boss-Schaden, Immunität, Pause, XP, Upgrade-Wahl, vollständigem Build, Sieg, Niederlage, Neustart, Loot-Grenzen und beschädigtem Speicher.

`npm run simulate` führt neun reproduzierbare Durchläufe mit drei unterschiedlichen Upgrade-Prioritäten und jeweils drei Seeds durch. Der einfache Bot sammelt XP, hält Abstand, nutzt den Schattenschritt und greift im Finale den Boss an. Er bekommt **keine zusätzliche Gesundheit, Unverwundbarkeit oder kostenlosen Waffen**. Ergebnisse: `reports/simulation.json`.

Der Browserprüfer verwendet für einzelne Randfälle absichtlich direkte Entwicklungseingriffe: sofortiges Level-up, volle Waffen, Bosszeit und erzwungene Endzustände. Diese prüfen die echte Darstellung und Zustandsübergänge, ersetzen jedoch keinen unbeschleunigten menschlichen 12-Minuten-Durchlauf. Der Zugang `window.__eclipse` existiert nur mit `?qa=1` **im Entwicklungsbuild**, niemals im Produktionsbuild.

Zusätzlich kann bei laufendem `npm run preview` der fertige Build mit `node scripts/production-smoke.mjs` geprüft werden. Dieser kurze Start-/Tastaturtest verändert keine Spielerwerte und kontrolliert auch, dass keine externen Ressourcen angefragt werden.

Siehe [QA.md](QA.md) für Ergebnisse, Balancing-Änderungen und Grenzen der Messungen. Referenz für die Phaser-Integration: [offizielle Phaser-Dokumentation](https://docs.phaser.io/phaser/concepts/textures).

## Bewusste Grenzen

- Ein Charakter, eine Arena, fünf Waffen und ein Boss. Keine zusätzlichen Charaktere, Online-Funktionen, Accounts oder permanente Kauf-Upgrades.
- Tastaturspiel: responsive Menüs sind vorhanden; Touch-Steuerung und Gamepads sind nicht implementiert.
- Keine Speicherung eines laufenden Durchlaufs. Verlassen über das Pausemenü zählt als aufgegeben; das Schließen des Tabs speichert keine unvollständige Runde.
- Eigene kompakte Pixel-Art mit begrenzter Framezahl und gespiegelten Richtungen; keine externen Asset-Pakete oder Studioproduktion.
- Balancing ist durch Simulation und technische Browserprüfungen gestützt, **nicht perfekt ausbalanciert**. Menschliches Playtesting, langfristige Schwierigkeit, subjektives Spielgefühl, Firefox/Safari und schwache reale GPUs benötigen weitere Prüfung.

## Assets und Lizenzen

Herkunft und Lizenz aller Grafiken und Klänge stehen in [ASSETS.md](ASSETS.md). Die fertigen PNGs sind enthalten; Python wird zum Starten oder Bauen **nicht** benötigt. Wer die Grafiken reproduzieren möchte, benötigt Python und Pillow und kann `python scripts/generate_assets.py` ausführen.
