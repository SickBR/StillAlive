import { Engine } from '../src/core/engine';
import { type UpgradeId } from '../src/core/config';
import { writeFileSync, mkdirSync } from 'node:fs';

const profiles:Record<string,UpgradeId[]>={
  'Klinge & Orbit':['blade','orb','power','haste','regen','vitality','frost','crit','speed','reach','fire','lightning'],
  'Elementar':['fire','lightning','frost','power','haste','regen','vitality','speed','reach','blade','orb','crit'],
  'Ausgewogen':['blade','orb','fire','lightning','frost','regen','power','vitality','haste','speed','crit','reach'],
};
const results=[];
for(const [name,priority] of Object.entries(profiles))for(const seed of [12,71,313]){
  const e=new Engine(seed);let maxEnemies=0,maxBullets=0;const started=performance.now();
  for(let tick=0;tick<60*850;tick++){
    if(e.status==='dead'||e.status==='won')break;
    if(e.status==='upgrade'){
      const scores=e.offers.map(o=>{const rank=priority.indexOf(o.id);const level=o.id in e.build.weapons?e.build.weapons[o.id as keyof typeof e.build.weapons]:e.build.passives[o.id as keyof typeof e.build.passives];return rank+level*.6-(e.player.hp/e.player.maxHp<.5&&['vitality','regen'].includes(o.id)?6:0);});
      e.selectUpgrade(scores.indexOf(Math.min(...scores)));
    }
    const p=e.player;
    // A simple deterministic kiting bot: nearby pickups, separation, arena-edge avoidance.
    const loot=e.loot.filter(l=>Math.hypot(l.x-p.x,l.y-p.y)<380).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];
    const angle=e.time*.027;
    let target:{x:number;y:number}=loot??{x:1600+Math.cos(angle)*420,y:1200+Math.sin(angle)*420};
    if(e.boss){const boss=e.boss,a=Math.atan2(p.y-boss.y,p.x-boss.x)+.24,radius=name==='Elementar'?190:100;target={x:boss.x+Math.cos(a)*radius,y:boss.y+Math.sin(a)*radius};}
    let dx=target.x-p.x,dy=target.y-p.y;const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
    let danger=0;
    for(const enemy of e.enemies){const dist=Math.hypot(p.x-enemy.x,p.y-enemy.y),safe=enemy.kind==='boss'?80:135;if(dist<safe){const weight=(safe-dist)/safe*2.4;dx+=(p.x-enemy.x)/(dist||1)*weight;dy+=(p.y-enemy.y)/(dist||1)*weight;danger+=weight;}}
    for(const b of e.projectiles)if(b.enemy){const dist=Math.hypot(p.x-b.x,p.y-b.y);if(dist<90){dx+=(p.x-b.x)/(dist||1)*1.4;dy+=(p.y-b.y)/(dist||1)*1.4;}}
    for(const w of e.warnings){const dist=Math.hypot(p.x-w.x,p.y-w.y);if(dist<w.radius+40){dx+=(p.x-w.x)/(dist||1)*3;dy+=(p.y-w.y)/(dist||1)*3;}}
    if(p.x<220)dx+=2;if(p.x>2980)dx-=2;if(p.y<220)dy+=2;if(p.y>2180)dy-=2;
    e.step(1/60,{x:dx,y:dy,dash:danger>2});e.drainEvents();maxEnemies=Math.max(maxEnemies,e.enemies.length);maxBullets=Math.max(maxBullets,e.projectiles.length);
  }
  const result={build:name,seed,result:e.status,time:Math.round(e.time),level:e.level,kills:e.kills,hp:Math.round(e.player.hp),bossHP:Math.round(e.boss?.hp??0),maxEnemies,maxBullets,simulationMs:Math.round(performance.now()-started),weapons:e.build.weapons,damage:Object.fromEntries(Object.entries(e.weaponDamage).map(([k,v])=>[k,Math.round(v)]))};
  results.push(result);console.log(JSON.stringify(result));
}
mkdirSync('reports',{recursive:true});writeFileSync('reports/simulation.json',JSON.stringify({note:'Deterministic heuristic bot, 60 Hz, no immunity/boosts; not a substitute for human playtesting.',results},null,2));
