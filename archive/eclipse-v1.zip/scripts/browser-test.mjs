import { chromium } from '@playwright/test';
import { mkdirSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import assert from 'node:assert/strict';

const root=process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA,'ms-playwright') : '';
const bundled=root&&existsSync(root)?readdirSync(root).filter(x=>/^chromium-/.test(x)).sort().reverse().map(x=>join(root,x,'chrome-win64','chrome.exe')).find(existsSync):undefined;
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||bundled,args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1440,height:900}});const errors=[];const failed=[];
page.on('pageerror',e=>errors.push(String(e)));page.on('response',r=>{if(r.status()>=400)failed.push(`${r.status()} ${r.url()}`);});
mkdirSync('reports/screenshots',{recursive:true});
const checks=[];
try{
  await page.goto(`${process.env.BASE_URL||'http://127.0.0.1:5173/'}?qa=1`);await page.waitForFunction(()=>window.__eclipse&&document.querySelector('[data-action=start]')?.disabled===false);
  await page.screenshot({path:'reports/screenshots/menu.png'});
  await page.getByRole('button',{name:'Einstellungen',exact:true}).click();await page.locator('#volume').focus();await page.keyboard.press('Home');for(let i=0;i<18;i++)await page.keyboard.press('ArrowRight');await page.getByRole('button',{name:'Zurück',exact:true}).click();
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('eclipse-survivor-v1')).settings.volume),.18);checks.push('Settings and LocalStorage');
  await page.getByRole('button',{name:'Steuerung',exact:true}).click();assert.ok(await page.getByText('Die Nacht überleben',{exact:true}).isVisible());await page.getByRole('button',{name:'Zurück',exact:true}).click();
  await page.getByRole('button',{name:'Statistiken',exact:true}).click();assert.ok(await page.getByText('Deine Chronik',{exact:true}).isVisible());await page.getByRole('button',{name:'Zurück',exact:true}).click();checks.push('Controls and statistics dialogs');
  await page.getByRole('button',{name:'Durchlauf beginnen'}).click();await page.waitForTimeout(300);
  const pos=await page.evaluate(()=>window.__eclipse.engine.player.x);await page.keyboard.down('d');await page.waitForTimeout(700);await page.keyboard.up('d');assert.ok(await page.evaluate(()=>window.__eclipse.engine.player.x)>pos+40);
  await page.keyboard.press('Space');await page.waitForTimeout(100);assert.ok(await page.evaluate(()=>window.__eclipse.engine.player.dashCooldown)>6);checks.push('Real keyboard movement and Shadow Step');
  await page.keyboard.press('Escape');const time=await page.evaluate(()=>window.__eclipse.engine.time);await page.waitForTimeout(400);assert.equal(await page.evaluate(()=>window.__eclipse.engine.time),time);await page.getByRole('button',{name:'Weiterkämpfen'}).click();checks.push('Pause freezes and resumes simulation');
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.player.invulnerable=1000;for(const id of Object.keys(e.build.weapons))e.build.weapons[id]=6;for(let i=0;i<40;i++){const a=i/40*Math.PI*2;const t=e.spawn(['hollow','crawler','brute','seer','reaper'][i%5],e.player.x+Math.cos(a)*(80+i*3),e.player.y+Math.sin(a)*(80+i*3));if(t){t.hp=3000;t.maxHp=3000;}}});
  await page.waitForTimeout(4800);await page.screenshot({path:'reports/screenshots/combat.png'});
  const damage=await page.evaluate(()=>window.__eclipse.engine.weaponDamage);for(const id of ['blade','orb','fire','frost','lightning'])assert.ok(damage[id]>0,`${id} damage in browser`);checks.push('All five weapons deal damage in real browser');
  await page.evaluate(()=>window.__eclipse.engine.addXp(100));await page.waitForTimeout(450);assert.equal(await page.locator('.upgrade-card').count(),3);await page.screenshot({path:'reports/screenshots/upgrades.png'});await page.keyboard.press('Digit1');
  while(await page.evaluate(()=>window.__eclipse.engine.status==='upgrade'))await page.keyboard.press('Digit1');checks.push('Upgrade selection by keyboard');
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.time=659.99;});await page.waitForTimeout(120);assert.ok(await page.locator('#boss-hud').isVisible());
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.boss.attack=0;});await page.waitForTimeout(150);await page.screenshot({path:'reports/screenshots/boss.png'});
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.hit(e.boss,999999,'blade');});await page.waitForTimeout(200);assert.ok(await page.getByText('Ein neuer Morgen.',{exact:true}).isVisible());checks.push('Boss spawn, attacks and victory screen');
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('eclipse-survivor-v1')).stats.wins),1);
  await page.getByRole('button',{name:'Noch einmal in die Nacht'}).click();await page.waitForTimeout(100);assert.equal(await page.evaluate(()=>window.__eclipse.engine.level),1);assert.equal(await page.evaluate(()=>window.__eclipse.engine.kills),0);
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.player.invulnerable=0;e.hurt(9999);});await page.waitForTimeout(150);assert.ok(await page.getByText('Im Schatten gefallen.',{exact:true}).isVisible());await page.screenshot({path:'reports/screenshots/defeat.png'});checks.push('Clean restart and defeat screen');
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('eclipse-survivor-v1')).stats.runs),2);checks.push('Run statistics are recorded exactly once');
  await page.getByRole('button',{name:'Erneut herausfordern'}).click();await page.waitForTimeout(100);
  await page.evaluate(()=>{const e=window.__eclipse.engine;e.player.invulnerable=10000;e.time=600;for(const id of Object.keys(e.build.weapons))e.build.weapons[id]=6;for(let i=0;i<230;i++){const a=i*2.4;e.spawn(i%7===0?'seer':'hollow',e.player.x+Math.cos(a)*(120+i*1.3),e.player.y+Math.sin(a)*(120+i*1.3));}});
  const perf=await page.evaluate(async()=>{const deltas=[];let last=performance.now();for(let i=0;i<180;i++)await new Promise(resolve=>requestAnimationFrame(now=>{deltas.push(now-last);last=now;const e=window.__eclipse.engine;if(e.status==='upgrade')e.selectUpgrade(0);resolve();}));deltas.sort((a,b)=>a-b);return {medianFrameMs:deltas[Math.floor(deltas.length*.5)],p95FrameMs:deltas[Math.floor(deltas.length*.95)],objects:window.__eclipse.scene.diagnostics,enemies:window.__eclipse.engine.enemies.length};});
  checks.push('Bounded-object load scenario (230 enemies at setup)');
  for(let i=0;i<6;i++){await page.evaluate(()=>window.__eclipse.start());await page.waitForTimeout(80);}
  const objectsAfterRestarts=await page.evaluate(()=>window.__eclipse.scene.diagnostics);assert.ok(objectsAfterRestarts.displayObjects<1200);checks.push('Six restarts without accumulating scene objects');
  await page.evaluate(()=>{localStorage.setItem('eclipse-survivor-v1','corrupt{');});await page.reload();await page.waitForFunction(()=>window.__eclipse&&document.querySelector('[data-action=start]')?.disabled===false);await page.getByRole('button',{name:'Durchlauf beginnen'}).click();assert.ok(await page.locator('#timer').isVisible());checks.push('Corrupt save recovery');
  await page.setViewportSize({width:390,height:844});await page.keyboard.press('Escape');await page.screenshot({path:'reports/screenshots/narrow.png'});checks.push('Narrow layout renders (keyboard required)');
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);
  const report={checks,errors,failed,damage,performance:perf,objectsAfterRestarts,note:'Headless Chromium using SwiftShader, not a hardware GPU benchmark. End screens and late encounters use development-only instrumentation.'};
  writeFileSync('reports/browser.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();}
