# Prüfung und Balancing

Stand: 3. Oktober 2026. Die Berichte stammen aus den tatsächlichen lokalen Prüfläufen.

## Automatisierte Prüfung

- Strikte TypeScript-Prüfung und Vite-Produktionsbuild.
- 20 Tests der tatsächlichen Simulation: normierte Bewegung und Arenagrenzen; Kontaktkollisionen und Todeszustand; Schaden und zeitlich begrenzte Immunität; Pause; Schattenschritt; XP und aufeinanderfolgende Level-ups; fünf Waffen separat; sieben passive Effekte; Verlangsamung, Kettensprünge und Durchdringung; Gegnerfreischaltung; Elite-/Fernkampf-/Boss-Angriffe; Sieg und Neustart; Loot-Limits; räumliche Abfragen; deterministische Zufallszahlen; Speicherfehler; Finsternis; vollständig entwickelte Builds; Boss-Übergang.
- Chromium-Browserabläufe: alle Menüs, Tastatureingabe, Lautstärke und Speicherung, Pause/Fortsetzen, fünf Waffen mit messbarem Schaden, Upgrade-Auswahl per Tastatur, Boss und beide Endbildschirme, sechs Neustarts, beschädigter LocalStorage und schmale Ansicht.
- Screenshots von Menü, Kampf, Upgrades, Boss, Niederlage und schmalem Pausemenü wurden erzeugt und visuell geprüft.
- Kein Laufzeitfehler und keine fehlende lokale Ressource im dokumentierten Browserprüflauf. Siehe `reports/browser.json`. Die Tests prüfen außerdem, dass Siege und Niederlagen genau einmal in die Statistik eingehen.
- Der Produktionsbuild wurde separat gestartet und etwa 15 Sekunden mit normalen Tastatureingaben gespielt, anschließend pausiert. Kein Entwicklungszugriff, keine Sonderwerte, keine externen Ressourcenanfragen und keine JavaScript-Fehler; der QA-Zugang fehlt auch mit `?qa=1`. Siehe `reports/production.json` und `reports/screenshots/production-gameplay.png`.

## Simulationen ohne Sonderboni

Neun deterministische Botläufe, 60 Simulationsschritte pro Sekunde. Der Bot sammelt XP, meidet Gegner/Geschosse/Markierungen und priorisiert ab Minute 11 den Boss. Keine vorgegebenen Maximalwaffen und keine zusätzlichen Spielerwerte.

| Build-Priorität | Seed | Ergebnis | Zeit | Level | Kills |
| --- | ---: | --- | ---: | ---: | ---: |
| Klinge & Orbit | 12 | Niederlage | 11:57 | 23 | 885 |
| Klinge & Orbit | 71 | Sieg | 12:06 | 26 | 1091 |
| Klinge & Orbit | 313 | Sieg | 13:22 | 27 | 1367 |
| Elementar | 12 | Sieg | 12:15 | 27 | 1303 |
| Elementar | 71 | Sieg | 11:21 | 38 | 2603 |
| Elementar | 313 | Sieg | 11:27 | 38 | 2344 |
| Ausgewogen | 12 | Sieg | 11:27 | 33 | 1921 |
| Ausgewogen | 71 | Sieg | 11:26 | 33 | 1987 |
| Ausgewogen | 313 | Sieg | 11:40 | 30 | 1646 |

Rohdaten mit Schaden je Waffe, Gegner-/Geschoss-Spitzen und Simulationsdauer: `reports/simulation.json`.

Diese kleine Stichprobe zeigt, dass alle drei Strategien gewinnen können. Sie ist keine statistisch belastbare Aussage zur menschlichen Gewinnrate. Nahkampf ist anfälliger für ungünstige Angebote und Positionierung; Elementar-Builds sind beim automatisierten Ausweichen im Vorteil. Das bleibt ein Schwerpunkt für menschliches Playtesting.

## Änderungen aus den Prüfungen

- Boss-LP von 15000 auf 6200 reduziert: Der ursprüngliche Endkampf war mit dem Nachschub unnötig lang.
- Boss erscheint in erreichbarer Distanz, erhält eine Richtungsanzeige und entfernt beim Eintritt seine übrigen Diener samt feindlichen Projektilen. Diese Entfernung gibt keine Spielerbelohnung.
- Nachschub im Finale auf einen Spawn pro 0,65 Sekunden reduziert; zweite Bossphase bleibt an halbe LP oder Minute 12 gekoppelt.
- Vier sichtbare Anfangsgegner vermeiden eine leere Anfangsphase.
- Sehr kurze Leertasten-Tipps werden bis zum nächsten Simulationsschritt gepuffert.
- Globale Phaser-Tastaturunterdrückung entfernt, damit der Lautstärkeregler mit Pfeiltasten bedienbar bleibt.
- Tests für Verlangsamung prüfen das aktive Zeitfenster; sie erwarten keine permanente Wirkung.

## Performance und Lebensdauer

Die Browserlastprüfung setzt bis zu 230 Gegner sowie alle fünf Waffen auf und misst 180 Browserframes. Der aufgezeichnete Lauf verwendete **Headless Chromium mit SwiftShader**, also Software-Rendering. Median ca. 33,3 ms, 95. Perzentil ca. 50 ms unter gleichzeitig laufenden Simulationen. Diese Zahlen sind ausdrücklich **kein 60-FPS-Versprechen für reale Hardware**. Neuere Messwerte stehen in `reports/browser.json`.

Der getestete Szenenbestand blieb über sechs weitere Neustarts konstant bei 528 Anzeigeobjekten inklusive wiederverwendbarer Pools. Ein Heap-Snapshot-Langzeittest wurde nicht durchgeführt; die Prüfung belegt begrenzte Objektzahlen in diesem Szenario, nicht die Abwesenheit jedes möglichen Speicherlecks.

Gegner (230), Geschosse (280), Loot (380), gleichzeitig laufende Effekte (180) und Schadenslabels (55) haben feste Grenzen. XP oberhalb der Loot-Grenze wird in einen vorhandenen XP-Drop zusammengeführt. Heildrops haben eine niedrige Chance beziehungsweise eine kleine Elite-Belohnung. Bilder und Schadenslabels werden wiederverwendet.

## Offene Playtesting-Fragen und Grenzen

- Subjektives Spielgefühl, langfristige Schwierigkeit und tatsächliche Lernkurve sind noch nicht durch menschliche Testgruppen bewertet.
- Kein ununterbrochener menschlicher 12-Minuten-Browsertest. Vollständige Läufe wurden mit der identischen Spiellogik im Bot simuliert; Browser-Endzustände wurden gezielt ausgelöst.
- Chromium wurde geprüft; Firefox, Safari und verschiedene reale GPUs nicht.
- Keine Touch-/Gamepad-Steuerung und keine Wiederaufnahme eines laufenden Durchlaufs.
- Spieldauer ist ungefähr zwölf Minuten. Der Boss kann früher fallen oder bei defensiver Spielweise länger leben; Minute 12 ist eine Eskalation und kein automatisches Spielende.

Es wird kein perfektes Balancing behauptet. Die dokumentierten Tests sichern Kernfunktionen und Spielbarkeit technisch ab; sie ersetzen kein ausgiebiges menschliches Playtesting.
