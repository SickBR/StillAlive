import { ENEMIES, RULES, WORLD, WEAPON_IDS, PASSIVE_EFFECTS, enemyScaling, spawnInterval, weaponStats, xpForLevel, type EnemyKind, type WeaponId, type PassiveId } from './config';
import { Random } from './random';
import { SpatialHash } from './spatial';
import { choices, initialBuild, type Upgrade } from './upgrades';

export interface Enemy { id: number; kind: EnemyKind; x: number; y: number; hp: number; maxHp: number; radius: number; speed: number; damage: number; slow: number; flash: number; attack: number; orbHit: number; facing: number; chargeX: number; chargeY: number; charge: number }
export interface Projectile { id: number; x: number; y: number; vx: number; vy: number; damage: number; enemy: boolean; life: number; radius: number; target: number; pierce: number; hit: Set<number> }
export interface Loot { id: number; x: number; y: number; value: number; heal: boolean }
export interface Warning { id: number; x: number; y: number; radius: number; remaining: number; duration: number; damage: number }
export interface GameEvent { type: string; x: number; y: number; value?: number; crit?: boolean; angle?: number; radius?: number; points?: { x: number; y: number }[]; kind?: string }
export type Status = 'playing' | 'paused' | 'upgrade' | 'dead' | 'won';
export interface Input { x: number; y: number; dash?: boolean }
const distance = (a: {x: number; y: number}, b: {x: number; y: number}) => Math.hypot(a.x-b.x, a.y-b.y);
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

export class Engine {
  rng: Random;
  status: Status = 'playing';
  time = 0; kills = 0; level = 1; xp = 0; damageDealt = 0;
  build = initialBuild();
  player = { x: WORLD.width/2, y: WORLD.height/2, hp: RULES.playerHp, maxHp: RULES.playerHp, invulnerable: 0, dashLeft: 0, dashCooldown: 0, directionX: 0, directionY: 1, moving: false };
  enemies: Enemy[] = []; projectiles: Projectile[] = []; loot: Loot[] = []; warnings: Warning[] = [];
  events: GameEvent[] = []; offers: Upgrade[] = [];
  grid = new SpatialHash<Enemy>();
  cooldowns: Record<WeaponId, number> = { blade: .4, orb: 0, fire: .2, frost: 1, lightning: .5 };
  weaponDamage: Record<WeaponId | 'dash', number> = { blade: 0, orb: 0, fire: 0, frost: 0, lightning: 0, dash: 0 };
  bossSpawned = false; bossDefeated = false;
  private nextId = 1; private spawnClock = .3; private eclipseWas = false;
  constructor(seed?: number) {
    this.rng = new Random(seed);
    for(let i=0;i<4;i++){const a=i/4*Math.PI*2+.4;this.spawn('hollow',this.player.x+Math.cos(a)*290,this.player.y+Math.sin(a)*290);}
  }
  get eclipse() { return this.time % RULES.eclipseCycle >= RULES.eclipseCycle - RULES.eclipseLength; }
  get damageMultiplier() { return 1 + this.build.passives.power * PASSIVE_EFFECTS.power; }
  get attackSpeed() { return 1 + this.build.passives.haste * PASSIVE_EFFECTS.haste; }
  get rangeMultiplier() { return 1 + this.build.passives.reach * PASSIVE_EFFECTS.reach; }
  get playerSpeed() { return RULES.playerSpeed * (1 + this.build.passives.speed * PASSIVE_EFFECTS.speed); }
  get criticalChance() { return .05 + this.build.passives.crit * PASSIVE_EFFECTS.crit; }
  get pickupRadius() { return RULES.pickupRadius * (1 + this.build.passives.reach * PASSIVE_EFFECTS.pickup); }
  get boss() { return this.enemies.find(e => e.kind === 'boss'); }
  drainEvents() { const result = this.events; this.events = []; return result; }
  emit(type: string, x = this.player.x, y = this.player.y, extra: Partial<GameEvent> = {}) { this.events.push({ type, x, y, ...extra }); }
  pause() { if (this.status === 'playing') this.status = 'paused'; else if (this.status === 'paused') this.status = 'playing'; }
  selectUpgrade(index: number) {
    if (this.status !== 'upgrade' || !this.offers[index]) return false;
    const upgrade = this.offers[index];
    this.applyUpgrade(upgrade); this.offers = []; this.status = 'playing'; this.checkLevel(); return true;
  }
  applyUpgrade(upgrade: Upgrade) {
    if(upgrade.recovery){
      if(upgrade.recovery==='vitality')this.player.maxHp+=10;
      if(upgrade.recovery==='dash')this.player.dashCooldown=0;
      this.player.hp=Math.min(this.player.maxHp,this.player.hp+(upgrade.recovery==='vitality'?10:upgrade.recovery==='dash'?20:35));this.emit('upgrade');return;
    }
    if (upgrade.id in this.build.weapons) this.build.weapons[upgrade.id as WeaponId] = Math.min(6, this.build.weapons[upgrade.id as WeaponId] + 1);
    else {
      const id = upgrade.id as PassiveId;
      if (this.build.passives[id] < 5) { this.build.passives[id]++; if (id === 'vitality') { this.player.maxHp += PASSIVE_EFFECTS.vitality; this.player.hp += PASSIVE_EFFECTS.vitality; } }
    }
    this.player.hp = Math.min(this.player.maxHp, this.player.hp + upgrade.bonus);
    this.emit('upgrade');
  }
  addXp(value: number) { this.xp += value; this.checkLevel(); }
  private checkLevel() {
    if (this.status !== 'playing' || this.xp < xpForLevel(this.level)) return;
    this.xp -= xpForLevel(this.level); this.level++; this.player.hp = Math.min(this.player.maxHp, this.player.hp+RULES.levelHeal);
    this.offers = choices(this.build, this.rng); this.status = 'upgrade'; this.emit('level');
  }
  spawn(kind?: EnemyKind, x?: number, y?: number): Enemy | undefined {
    if (this.enemies.length >= RULES.enemyCap && kind !== 'boss') return;
    if (!kind) {
      const roll = this.rng.next();
      kind = this.time >= 270 && roll < .07 ? 'reaper' : this.time >= 170 && roll < .20 ? 'seer' : this.time >= 100 && roll < .34 ? 'brute' : this.time >= 35 && roll < .58 ? 'crawler' : 'hollow';
    }
    if (x === undefined || y === undefined) {
      const angle = this.rng.between(0, Math.PI*2), r = this.rng.between(610, 780);
      x = clamp(this.player.x + Math.cos(angle)*r, 40, WORLD.width-40); y = clamp(this.player.y + Math.sin(angle)*r, 40, WORLD.height-40);
      if (Math.hypot(x-this.player.x,y-this.player.y) < 360) { x = clamp(this.player.x-Math.cos(angle)*r,40,WORLD.width-40); y = clamp(this.player.y-Math.sin(angle)*r,40,WORLD.height-40); }
    }
    const stats = ENEMIES[kind], scale = kind === 'boss' ? 1 : enemyScaling(this.time);
    const e: Enemy = { id: this.nextId++, kind, x, y, hp: stats.hp*scale, maxHp: stats.hp*scale, speed: stats.speed, damage: stats.damage * (1+this.time/1600), radius: stats.radius, slow: 0, flash: 0, attack: kind === 'boss' ? 2.5 : this.rng.between(1.2,3), orbHit: 0, facing: 1, chargeX: 0, chargeY: 0, charge: 0 };
    this.enemies.push(e); return e;
  }
  step(dt: number, input: Input) {
    if (this.status !== 'playing' || !Number.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, .05); this.time += dt;
    if (this.eclipse !== this.eclipseWas) { this.eclipseWas = this.eclipse; this.emit('eclipse', undefined, undefined, { value: this.eclipse ? 1 : 0 }); }
    const p = this.player;
    p.invulnerable = Math.max(0,p.invulnerable-dt); p.dashCooldown = Math.max(0,p.dashCooldown-dt);
    p.hp = Math.min(p.maxHp,p.hp + this.build.passives.regen*PASSIVE_EFFECTS.regen*dt);
    const length = Math.hypot(input.x,input.y), dx = length ? input.x/length : 0, dy = length ? input.y/length : 0;
    if (length) { p.directionX = dx; p.directionY = dy; }
    this.grid.rebuild(this.enemies.filter(e=>e.hp>0));
    if (input.dash && p.dashCooldown === 0) {
      p.dashCooldown = RULES.dashCooldown; p.dashLeft = RULES.dashDuration; p.invulnerable = RULES.dashDuration+.15;
      this.emit('dash',p.x,p.y,{radius:140});
      for (const e of this.grid.query(p.x,p.y,140)) this.hit(e,RULES.dashDamage*(this.eclipse?RULES.eclipseDashBonus:1),'dash');
    }
    const dashing = p.dashLeft > 0;
    p.x = clamp(p.x + (dashing?p.directionX:dx) * (dashing?RULES.dashSpeed:this.playerSpeed)*dt, 32,WORLD.width-32);
    p.y = clamp(p.y + (dashing?p.directionY:dy) * (dashing?RULES.dashSpeed:this.playerSpeed)*dt, 32,WORLD.height-32);
    p.dashLeft = Math.max(0,p.dashLeft-dt); p.moving = length>0 || dashing;
    this.spawnClock -= dt;
    if (this.spawnClock <= 0) { this.spawnClock += this.bossSpawned?RULES.finaleSpawnInterval:spawnInterval(this.time); this.spawn(); if(this.time>360&&!this.bossSpawned) this.spawn(); }
    if (!this.bossSpawned && this.time >= RULES.bossAt) {
      // The boss consumes its servants. No player kills or XP are awarded for this transition.
      for(const enemy of this.enemies)this.emit('death',enemy.x,enemy.y,{kind:enemy.kind});
      this.enemies=[];this.projectiles=this.projectiles.filter(b=>!b.enemy);
      this.bossSpawned=true; this.spawn('boss',clamp(p.x+(p.x<WORLD.width/2?380:-380),60,WORLD.width-60),clamp(p.y-100,60,WORLD.height-60)); this.emit('boss');
    }
    this.updateEnemies(dt);
    this.grid.rebuild(this.enemies.filter(e=>e.hp>0));
    if (this.status !== 'playing') return;
    this.updateWeapons(dt); this.updateProjectiles(dt); this.updateWarnings(dt); this.updateLoot(dt);
    this.enemies = this.enemies.filter(e => e.hp>0);
    if (this.bossDefeated && this.player.hp > 0) { this.status='won'; this.emit('won'); }
  }
  private updateEnemies(dt: number) {
    const p = this.player;
    for (const e of this.enemies) {
      if(e.hp<=0) continue;
      e.slow = Math.max(0,e.slow-dt); e.flash = Math.max(0,e.flash-dt); e.orbHit = Math.max(0,e.orbHit-dt); e.attack-=dt;
      const dist = distance(e,p), dx = (p.x-e.x)/(dist||1), dy = (p.y-e.y)/(dist||1);
      e.facing = dx < 0 ? -1 : 1;
      let movement = 1;
      if(e.kind==='seer') {
        movement = dist<220 ? -.65 : dist<320 ? 0 : 1;
        if(e.attack<=0 && dist<640) { this.shoot(e.x,e.y,dx*190,dy*190,e.damage,true); e.attack=3.1; this.emit('cast',e.x,e.y); }
      }
      if(e.kind==='reaper') {
        if(e.attack<=0 && dist<390) { e.charge=.85; e.chargeX=dx; e.chargeY=dy; e.attack=5; this.emit('charge',e.x,e.y); }
      }
      if(e.kind==='boss' && e.attack<=0) {
        const phase2 = e.hp<e.maxHp*.5 || this.time>=RULES.duration;
        const count = phase2?18:12;
        for(let i=0;i<count;i++) { const a=i/count*Math.PI*2+this.time*.25; this.shoot(e.x,e.y,Math.cos(a)*155,Math.sin(a)*155,e.damage*.65,true); }
        for(let i=0;i<(phase2?4:2);i++) {
          this.warnings.push({id:this.nextId++,x:clamp(p.x+this.rng.between(-140,140),35,WORLD.width-35),y:clamp(p.y+this.rng.between(-140,140),35,WORLD.height-35),radius:65,remaining:1.35,duration:1.35,damage:24});
        }
        e.attack=phase2?2.7:3.7; this.emit('cast',e.x,e.y);
      }
      let vx=dx*movement, vy=dy*movement;
      for(const other of this.grid.query(e.x,e.y,e.radius+28)) {
        if(other.id===e.id || other.hp<=0) continue;
        const d=distance(e,other), overlap=e.radius+other.radius-d;
        if(overlap>0 && d>.01) { vx+=(e.x-other.x)/d*overlap*.07; vy+=(e.y-other.y)/d*overlap*.07; }
      }
      let speed=e.speed*(e.slow>0?.45:1)*(this.eclipse?1.15:1);
      if(e.charge>0) { e.charge-=dt; if(e.charge>.5) speed=0; else {vx=e.chargeX;vy=e.chargeY;speed=265;} }
      e.x=clamp(e.x+vx*speed*dt,18,WORLD.width-18); e.y=clamp(e.y+vy*speed*dt,18,WORLD.height-18);
      if(distance(e,p)<e.radius+12) this.hurt(e.damage);
      // Recycle distant stragglers toward the current encounter without growing the population.
      if(dist>1250 && e.kind!=='boss') { const a=this.rng.between(0,Math.PI*2); e.x=clamp(p.x+Math.cos(a)*730,40,WORLD.width-40); e.y=clamp(p.y+Math.sin(a)*730,40,WORLD.height-40); }
    }
  }
  orbPositions() {
    const level=this.build.weapons.orb; if(!level) return [];
    const s=weaponStats('orb',level), radius=s.range*this.rangeMultiplier;
    return Array.from({length:s.count},(_,i)=>{const a=this.time*2.4+i/s.count*Math.PI*2;return {x:this.player.x+Math.cos(a)*radius,y:this.player.y+Math.sin(a)*radius};});
  }
  private updateWeapons(dt: number) {
    const p=this.player;
    for(const id of WEAPON_IDS) {
      const level=this.build.weapons[id]; if(!level) continue;
      const s=weaponStats(id,level), range=s.range*this.rangeMultiplier;
      this.cooldowns[id]-=dt;
      if(id==='orb') {
        for(const orb of this.orbPositions()) for(const e of this.grid.query(orb.x,orb.y,43)) if(e.orbHit<=0 && distance(orb,e)<e.radius+19) {this.hit(e,s.damage,id);e.orbHit=s.cooldown/this.attackSpeed;}
        continue;
      }
      if(this.cooldowns[id]>0) continue;
      const targets=this.grid.query(p.x,p.y,range).filter(e=>e.hp>0).sort((a,b)=>distance(a,p)-distance(b,p));
      if(!targets.length) { this.cooldowns[id]=.08; continue; }
      this.cooldowns[id]=s.cooldown/this.attackSpeed;
      const first=targets[0], angle=Math.atan2(first.y-p.y,first.x-p.x);
      if(id==='blade') {
        this.emit('blade',p.x,p.y,{angle,radius:range});
        for(const e of targets) { const a=Math.atan2(e.y-p.y,e.x-p.x); if(Math.cos(a-angle)>-.55 || distance(e,p)<38) this.hit(e,s.damage*(this.eclipse?RULES.eclipseBladeBonus:1),id); }
      }
      if(id==='fire') for(let i=0;i<s.count;i++) {
        const target=targets[i%targets.length], a=Math.atan2(target.y-p.y,target.x-p.x)+(i-(s.count-1)/2)*.08;
        this.shoot(p.x,p.y,Math.cos(a)*360,Math.sin(a)*360,s.damage,false,target.id,level>=4?1:0); this.emit('fire',p.x,p.y);
      }
      if(id==='frost') { this.emit('frost',p.x,p.y,{radius:range}); for(const e of targets) {this.hit(e,s.damage,id);e.slow=2.2+level*.22;} }
      if(id==='lightning') {
        const struck=new Set<number>(), points=[{x:p.x,y:p.y}]; let current: Enemy|undefined=first;
        for(let i=0;i<s.count && current;i++) {
          struck.add(current.id); points.push({x:current.x,y:current.y}); this.hit(current,s.damage*(1-i*.055),id);
          const source: Enemy=current;
          current=this.grid.query(source.x,source.y,180*this.rangeMultiplier).filter(e=>e.hp>0&&!struck.has(e.id)).sort((a,b)=>distance(a,source)-distance(b,source))[0];
        }
        this.emit('lightning',p.x,p.y,{points});
      }
    }
  }
  private shoot(x:number,y:number,vx:number,vy:number,damage:number,enemy:boolean,target=0,pierce=0) {
    if(this.projectiles.length>=RULES.projectileCap) return;
    this.projectiles.push({id:this.nextId++,x,y,vx,vy,damage,enemy,life:enemy?5:2.2,radius:enemy?7:9,target,pierce,hit:new Set()});
  }
  private updateProjectiles(dt:number) {
    for(const b of this.projectiles) {
      b.life-=dt;
      if(!b.enemy && b.target) {const target=this.enemies.find(e=>e.id===b.target&&e.hp>0);if(target){const angle=Math.atan2(target.y-b.y,target.x-b.x);b.vx+=(Math.cos(angle)*360-b.vx)*Math.min(1,dt*6);b.vy+=(Math.sin(angle)*360-b.vy)*Math.min(1,dt*6);}}
      b.x+=b.vx*dt;b.y+=b.vy*dt;
      if(b.enemy) {if(distance(b,this.player)<b.radius+12){this.hurt(b.damage);b.life=0;}}
      else for(const e of this.grid.query(b.x,b.y,60)) {
        if(e.hp>0&&!b.hit.has(e.id)&&distance(b,e)<b.radius+e.radius) {this.hit(e,b.damage,'fire');b.hit.add(e.id);if(b.pierce--<=0){b.life=0;break;}}
      }
    }
    this.projectiles=this.projectiles.filter(b=>b.life>0&&b.x>0&&b.y>0&&b.x<WORLD.width&&b.y<WORLD.height);
  }
  private updateWarnings(dt:number) {
    for(const w of this.warnings) {w.remaining-=dt;if(w.remaining<=0){this.emit('impact',w.x,w.y,{radius:w.radius});if(distance(w,this.player)<w.radius+10)this.hurt(w.damage);}}
    this.warnings=this.warnings.filter(w=>w.remaining>0);
  }
  private updateLoot(dt:number) {
    const p=this.player, kept:Loot[]=[];
    for(const drop of this.loot) {
      const d=distance(drop,p);
      if(d<this.pickupRadius) {const speed=(240+(this.pickupRadius-d)*6)*dt;drop.x+=(p.x-drop.x)/(d||1)*Math.min(d,speed);drop.y+=(p.y-drop.y)/(d||1)*Math.min(d,speed);}
      if(distance(drop,p)<18) { if(drop.heal){p.hp=Math.min(p.maxHp,p.hp+drop.value);this.emit('heal',p.x,p.y,{value:drop.value});}else this.xp+=drop.value; }
      else kept.push(drop);
    }
    this.loot=kept;this.checkLevel();
  }
  hit(e:Enemy,baseDamage:number,weapon:WeaponId|'dash') {
    if(e.hp<=0)return;
    const crit=this.rng.next()<this.criticalChance, damage=baseDamage*this.damageMultiplier*(crit?2:1);
    const actual=Math.min(e.hp,damage);this.damageDealt+=actual;this.weaponDamage[weapon]+=actual;e.hp-=damage;e.flash=.12;
    this.emit('hit',e.x,e.y,{value:Math.round(damage),crit,kind:e.kind});
    if(e.hp<=0) {
      this.kills++;this.emit('death',e.x,e.y,{kind:e.kind});
      if(e.kind==='boss')this.bossDefeated=true;
      this.drop(e.x,e.y,ENEMIES[e.kind].xp,false);
      if(this.rng.next()<.018 || e.kind==='reaper')this.drop(e.x+10,e.y, e.kind==='reaper'?12:16,true);
    }
  }
  drop(x:number,y:number,value:number,heal:boolean) {
    if(this.loot.length>=RULES.lootCap) {
      if(!heal){const nearby=this.loot.filter(l=>!l.heal).sort((a,b)=>Math.hypot(a.x-x,a.y-y)-Math.hypot(b.x-x,b.y-y))[0];if(nearby)nearby.value+=value;}return;
    }
    this.loot.push({id:this.nextId++,x,y,value,heal});
  }
  hurt(damage:number) {
    const p=this.player;if(p.invulnerable>0||this.status!=='playing')return;
    p.hp=Math.max(0,p.hp-damage);p.invulnerable=RULES.invulnerability;this.emit('hurt',p.x,p.y,{value:Math.round(damage)});
    if(p.hp<=0){this.status='dead';this.emit('dead');}
  }
}
