export interface Settings { volume: number; shake: boolean; numbers: boolean; particles: boolean }
export interface Save { version: 1; settings: Settings; stats: { runs: number; wins: number; kills: number; bestTime: number; bestLevel: number } }
export const freshSave = (): Save => ({version:1,settings:{volume:.35,shake:true,numbers:true,particles:true},stats:{runs:0,wins:0,kills:0,bestTime:0,bestLevel:1}});
const finite = (n:unknown,fallback:number,max=1e9) => typeof n==='number'&&Number.isFinite(n)&&n>=0 ? Math.min(n,max):fallback;
export function decodeSave(raw:string|null):Save {
  const fallback=freshSave();try {
    if(!raw)return fallback;const value=JSON.parse(raw);if(!value||value.version!==1)return fallback;
    const s=value.settings??{},stats=value.stats??{};
    return {version:1,settings:{volume:finite(s.volume,.35,1),shake:typeof s.shake==='boolean'?s.shake:true,numbers:typeof s.numbers==='boolean'?s.numbers:true,particles:typeof s.particles==='boolean'?s.particles:true},stats:{runs:Math.floor(finite(stats.runs,0)),wins:Math.floor(finite(stats.wins,0)),kills:Math.floor(finite(stats.kills,0)),bestTime:finite(stats.bestTime,0),bestLevel:Math.floor(finite(stats.bestLevel,1))}};
  }catch{return fallback;}
}
export function readSave():Save {try{return decodeSave(localStorage.getItem('eclipse-survivor-v1'));}catch{return freshSave();}}
export function writeSave(save:Save):boolean {try{localStorage.setItem('eclipse-survivor-v1',JSON.stringify(save));return true;}catch{return false;}}
