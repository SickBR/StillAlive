import { PASSIVE_IDS, PASSIVES, WEAPON_IDS, WEAPONS, type UpgradeId, type WeaponId, type PassiveId, weaponStats } from './config';
import type { Random } from './random';
export interface Build { weapons: Record<WeaponId, number>; passives: Record<PassiveId, number> }
export interface Upgrade { id: UpgradeId; rarity: 'common' | 'rare' | 'epic'; bonus: number; recovery?: 'heal' | 'vitality' | 'dash' }
export const initialBuild = (): Build => ({ weapons: { blade: 1, orb: 0, fire: 0, frost: 0, lightning: 0 }, passives: { power: 0, haste: 0, speed: 0, vitality: 0, regen: 0, crit: 0, reach: 0 } });
export function choices(build: Build, rng: Random): Upgrade[] {
  const pool: UpgradeId[] = [...WEAPON_IDS.filter(id => build.weapons[id] < 6), ...PASSIVE_IDS.filter(id => build.passives[id] < 5)];
  const result: Upgrade[] = [];
  while (pool.length && result.length < 3) {
    const id = pool.splice(Math.floor(rng.next() * pool.length), 1)[0];
    const roll = rng.next(); const rarity = roll < .10 ? 'epic' : roll < .36 ? 'rare' : 'common';
    result.push({ id, rarity, bonus: rarity === 'epic' ? 18 : rarity === 'rare' ? 8 : 0 });
  }
  // Even nearly completed builds always offer three distinct, functioning options.
  for(const id of ['vitality','regen','haste','power','speed'] as const){
    if(result.length===3)break;
    if(!result.some(o=>o.id===id))result.push({id,rarity:'epic',bonus:0,recovery:id==='vitality'?'vitality':id==='haste'?'dash':'heal'});
  }
  return result;
}
export function upgradeDescription(upgrade: Upgrade, build: Build): string {
  if(upgrade.recovery==='heal')return 'Dein Build ist ausgereift. Stelle sofort 35 LP wieder her.';
  if(upgrade.recovery==='vitality')return 'Dein Build ist ausgereift. +10 maximale LP, heilt 10 LP.';
  if(upgrade.recovery==='dash')return 'Dein Build ist ausgereift. Schattenschritt sofort bereit und +20 LP Heilung.';
  if (upgrade.id in WEAPONS) {
    const id = upgrade.id as WeaponId, level = build.weapons[id];
    if (!level) return `${WEAPONS[id].subtitle} ${Math.round(weaponStats(id, 1).damage)} Basisschaden.`;
    const before = weaponStats(id, level), after = weaponStats(id, Math.min(6, level+1));
    return `Schaden ${Math.round(before.damage)} → ${Math.round(after.damage)} · schneller & größere Reichweite${after.count > before.count ? ' · +1 Projektil' : ''}`;
  }
  return PASSIVES[upgrade.id as PassiveId].description;
}
