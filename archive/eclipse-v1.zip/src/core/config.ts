export const WORLD = { width: 3200, height: 2400 };
export const RULES = {
  duration: 720, bossAt: 660, eclipseCycle: 90, eclipseLength: 20,
  playerSpeed: 172, playerHp: 110, pickupRadius: 76, invulnerability: .65,
  dashCooldown: 8, dashDuration: .32, dashSpeed: 580,
  enemyCap: 230, projectileCap: 280, lootCap: 380,
  dashDamage: 55, eclipseBladeBonus: 1.35, eclipseDashBonus: 1.5,
  levelHeal: 5, finaleSpawnInterval: .65,
};
export const PASSIVE_EFFECTS = { power: .12, haste: .09, speed: .08, vitality: 20, regen: .35, crit: .07, reach: .1, pickup: .25 };
export type WeaponId = 'blade' | 'orb' | 'fire' | 'frost' | 'lightning';
export type PassiveId = 'power' | 'haste' | 'speed' | 'vitality' | 'regen' | 'crit' | 'reach';
export type UpgradeId = WeaponId | PassiveId;
export type EnemyKind = 'hollow' | 'crawler' | 'brute' | 'seer' | 'reaper' | 'boss';
export const WEAPONS: Record<WeaponId, { name: string; subtitle: string; color: string; damage: number; cooldown: number; range: number }> = {
  blade: { name: 'Shadow Blade', subtitle: 'Ein weiter Hieb aus reiner Finsternis.', color: '#ba9bea', damage: 30, cooldown: 1.05, range: 102 },
  orb: { name: 'Arcane Orb', subtitle: 'Runenkugeln kreisen um dich.', color: '#95bce8', damage: 16, cooldown: .55, range: 88 },
  fire: { name: 'Firebolt', subtitle: 'Suchende Feuerbolzen jagen nahe Gegner.', color: '#eaa877', damage: 26, cooldown: 1.55, range: 480 },
  frost: { name: 'Frost Nova', subtitle: 'Eine Eiswelle verletzt und verlangsamt.', color: '#9bddda', damage: 20, cooldown: 4.2, range: 148 },
  lightning: { name: 'Lightning Chain', subtitle: 'Blitze springen zwischen Gegnern.', color: '#dfce8c', damage: 29, cooldown: 2.5, range: 350 },
};
export const ENEMIES: Record<EnemyKind, { name: string; hp: number; speed: number; damage: number; xp: number; radius: number; unlock: number }> = {
  hollow: { name: 'Aschenpilger', hp: 28, speed: 43, damage: 10, xp: 2, radius: 15, unlock: 0 },
  crawler: { name: 'Rissläufer', hp: 17, speed: 103, damage: 7, xp: 2, radius: 11, unlock: 35 },
  brute: { name: 'Gruftwächter', hp: 145, speed: 32, damage: 20, xp: 8, radius: 24, unlock: 100 },
  seer: { name: 'Leerseher', hp: 52, speed: 54, damage: 12, xp: 5, radius: 15, unlock: 170 },
  reaper: { name: 'Rissritter', hp: 225, speed: 64, damage: 18, xp: 14, radius: 19, unlock: 270 },
  boss: { name: 'DER ENTTHRONTE', hp: 6200, speed: 43, damage: 26, xp: 200, radius: 43, unlock: 660 },
};
export const PASSIVES: Record<PassiveId, { name: string; description: string; color: string }> = {
  power: { name: 'Dunkler Pakt', description: '+12 % Schaden für alle Waffen', color: '#bc92ce' },
  haste: { name: 'Rasende Runen', description: '+9 % Angriffstempo für alle Waffen', color: '#d6b991' },
  speed: { name: 'Nebeltritt', description: '+8 % Bewegungsgeschwindigkeit', color: '#a6bfba' },
  vitality: { name: 'Eisernes Herz', description: '+20 maximale LP, heilt 20 LP', color: '#da9191' },
  regen: { name: 'Blutwurzel', description: '+0,35 LP Regeneration pro Sekunde', color: '#a0bf88' },
  crit: { name: 'Tödlicher Blick', description: '+7 % Chance auf doppelten Schaden', color: '#d8c383' },
  reach: { name: 'Grenzenlos', description: '+10 % Waffenreichweite, +25 % Sammelradius', color: '#94b6dd' },
};
export const WEAPON_IDS = Object.keys(WEAPONS) as WeaponId[];
export const PASSIVE_IDS = Object.keys(PASSIVES) as PassiveId[];
export const xpForLevel = (level: number) => Math.floor(8 + level * 5 + level ** 1.38 * 1.5);
export const spawnInterval = (time: number) => Math.max(.13, .88 - time / 850);
export const enemyScaling = (time: number) => 1 + time / 520;
export function weaponStats(id: WeaponId, level: number) {
  const w = WEAPONS[id];
  return { damage: w.damage * (1 + (level - 1) * .32), cooldown: w.cooldown / (1 + (level - 1) * .09), range: w.range * (1 + (level - 1) * .075), count: id === 'orb' ? 1 + Math.floor(level / 2) : id === 'fire' ? 1 + Math.floor((level - 1) / 2) : id === 'lightning' ? 3 + level : 1 };
}
