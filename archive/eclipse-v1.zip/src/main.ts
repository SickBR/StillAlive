import Phaser from 'phaser';
import { Engine } from './core/engine';
import { readSave, writeSave } from './core/storage';
import { GameScene } from './render/GameScene';
import { AudioBus } from './audio';
import { UI } from './ui';
import './style.css';

const save=readSave(), audio=new AudioBus(), scene=new GameScene();
audio.setVolume(save.settings.volume);scene.settings=save.settings;
let engine:Engine|undefined,ready=false,recorded=false,lastStatus='';
function persist(){if(!writeSave(save))ui.toast('Speicher nicht verfügbar. Diese Sitzung bleibt spielbar.');}
function record(){
  if(!engine||recorded)return;recorded=true;
  save.stats.runs++;save.stats.kills+=engine.kills;if(engine.status==='won')save.stats.wins++;
  save.stats.bestTime=Math.max(save.stats.bestTime,engine.time);save.stats.bestLevel=Math.max(save.stats.bestLevel,engine.level);persist();
}
function start(){
  if(!ready)return;
  if(engine)record();
  audio.start();engine=new Engine();recorded=false;lastStatus='playing';scene.startRun(engine);ui.startHud();ui.update(engine,true);
  ui.toast('WASD bewegen · Angriffe automatisch · LEERTASTE Schattenschritt');
}
function pause(){
  if(!engine)return;
  const dialog=document.querySelector('.dialog-layer');if(dialog){dialog.remove();return;}
  engine.pause();if(engine.status==='paused')audio.pause();else if(engine.status==='playing')audio.start();
  ui.overlay(engine);lastStatus=engine.status;
}
const ui=new UI(save,{
  start,resume:pause,pause,
  menu:()=>{record();engine=undefined;scene.clearRun();lastStatus='';audio.pause();ui.menu();},
  upgrade:index=>{if(engine?.selectUpgrade(index)){ui.overlay(engine);lastStatus=engine.status;ui.update(engine,true);}},
  settings:value=>{scene.settings=value;audio.setVolume(value.volume);persist();},
});
ui.menu();
scene.onReady=()=>{ready=true;document.querySelector<HTMLButtonElement>('[data-action=start]')?.removeAttribute('disabled');};
document.querySelector<HTMLButtonElement>('[data-action=start]')?.setAttribute('disabled','');
scene.onPause=pause;
scene.onEvent=event=>{
  audio.play(event.type);
  if(event.type==='eclipse')ui.toast(event.value?'FINSTERNIS · Schattenangriffe verstärkt. Gegner werden schneller.':'Die Finsternis weicht. Für einen Moment.');
  if(event.type==='boss')ui.toast('DER ENTTHRONTE · Besiege ihn und versiegle den Riss!');
};
scene.onTick=()=>{
  if(!engine)return;ui.update(engine);
  if(engine.status!==lastStatus){lastStatus=engine.status;ui.overlay(engine);if(engine.status==='dead'||engine.status==='won')record();}
};
const game=new Phaser.Game({
  type:Phaser.AUTO,parent:'game',width:1280,height:720,backgroundColor:'#1c2428',pixelArt:true,roundPixels:true,
  scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[scene],
  audio:{noAudio:true},fps:{target:60,smoothStep:true},render:{antialias:false},
});
document.addEventListener('keydown',event=>{
  if(event.code==='Escape'&&!engine){document.querySelector('.dialog-layer')?.remove();return;}
  if(engine?.status==='upgrade'&&['Digit1','Digit2','Digit3'].includes(event.code)&&!event.repeat){engine.selectUpgrade(Number(event.code.slice(-1))-1);ui.overlay(engine);lastStatus=engine.status;}
  if(event.code==='Tab'){
    const modal=document.querySelector<HTMLElement>('.dialog-layer,.overlay-backdrop');if(!modal)return;
    const items=[...modal.querySelectorAll<HTMLElement>('button,input,[tabindex="0"]')];if(!items.length)return;
    if(event.shiftKey&&document.activeElement===items[0]){event.preventDefault();items.at(-1)?.focus();}else if(!event.shiftKey&&document.activeElement===items.at(-1)){event.preventDefault();items[0].focus();}
  }
});
function blur(){if(engine?.status==='playing'){engine.pause();audio.pause();ui.overlay(engine);lastStatus=engine.status;}}
window.addEventListener('blur',blur);document.addEventListener('visibilitychange',()=>{if(document.hidden)blur();});
window.addEventListener('pagehide',()=>{if(engine&&(engine.status==='dead'||engine.status==='won'))record();});

// Opt-in instrumentation is only present in Vite development builds.
if(import.meta.env.DEV&&new URLSearchParams(location.search).has('qa')){
  Object.assign(window,{__eclipse:{get engine(){return engine;},get scene(){return scene;},get game(){return game;},start,save,pause}});
}
