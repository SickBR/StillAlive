import { RULES, WEAPON_IDS, WEAPONS, PASSIVES, xpForLevel, type WeaponId, type PassiveId } from './core/config';
import type { Engine } from './core/engine';
import { upgradeDescription } from './core/upgrades';
import type { Save, Settings } from './core/storage';

export const formatTime=(seconds:number)=>`${Math.floor(seconds/60).toString().padStart(2,'0')}:${Math.floor(seconds%60).toString().padStart(2,'0')}`;
const icon=(id:string,cls='')=>`<img class="item-icon ${cls}" src="assets/icon-${id}.png" alt="" draggable="false">`;
const brand=`<div class="brand-mark"><img src="assets/icon.png" alt=""><span>ECLIPSE<span class="brand-sub">SURVIVOR</span></span></div>`;
export interface Actions {start:()=>void;resume:()=>void;pause:()=>void;menu:()=>void;upgrade:(index:number)=>void;settings:(value:Settings)=>void}
export class UI {
  root=document.querySelector<HTMLElement>('#ui')!;
  view='';private hud?:HTMLElement;private lastHud=0;private toastTimeout?:ReturnType<typeof setTimeout>;
  constructor(public save:Save,private actions:Actions){
    this.root.addEventListener('click',event=>{
      const button=(event.target as HTMLElement).closest<HTMLElement>('[data-action]');if(!button)return;
      const action=button.dataset.action;
      if(action==='start')actions.start();if(action==='resume')actions.resume();if(action==='pause')actions.pause();if(action==='menu')actions.menu();
      if(action==='upgrade')actions.upgrade(Number(button.dataset.index));
      if(action==='settings')this.settings();if(action==='controls')this.controls();if(action==='stats')this.stats();if(action==='back')this.menu();if(action==='close-dialog')this.root.querySelector('.dialog-layer')?.remove();
    });
    this.root.addEventListener('input',event=>{
      const target=event.target as HTMLInputElement;if(!target.dataset.setting)return;
      const key=target.dataset.setting as keyof Settings;
      const next={...this.save.settings,[key]:key==='volume'?Number(target.value):target.checked};this.save.settings=next;actions.settings(next);
      const volume=this.root.querySelector('#volume-value');if(volume)volume.textContent=`${Math.round(next.volume*100)} %`;
    });
  }
  menu(){
    this.view='menu';this.root.className='menu-screen';this.root.innerHTML=`
      <div class="vista" aria-hidden="true"></div><div class="menu-shade"></div><div class="grain"></div>
      <header class="menu-header">${brand}<div class="edition"><span class="status-dot"></span> LOCAL EDITION <span class="version">v1.0</span></div></header>
      <div class="menu-main"><div class="eyebrow"><span></span> DAS LICHT VERBLASST. DU BLEIBST.</div>
        <h1>ECLIPSE<span>SURVIVOR</span></h1>
        <p class="intro">Die letzte Nacht hat begonnen.<br>Stell dich der Finsternis. Versiegle den Riss.</p>
        <div class="menu-buttons"><button class="primary start-button" data-action="start"><span>Durchlauf beginnen</span><span class="button-arrow" aria-hidden="true">→</span></button>
        <div class="secondary-actions"><button data-action="settings">Einstellungen</button><button data-action="stats">Statistiken</button><button data-action="controls">Steuerung</button></div></div>
        <div class="character-card"><div class="portrait"><img src="assets/portrait.png" alt="Shadow Knight in dunkler Rüstung"></div><div><span class="small-label">DEIN ÜBERLEBENDER</span><h3>Shadow Knight</h3><p>Stahl im Herzen. Schatten in der Klinge.</p><div class="character-tags"><span>NAHKAMPF</span><span>SCHATTENSCHRITT</span></div></div><span class="selected-dot" title="Ausgewählt"></span></div>
      </div>
      <aside class="location"><span class="small-label">DAS ZERBROCHENE KLOSTER</span><p>Wo einst Gebete waren,<br>antworten nur noch Schatten.</p><div class="location-line"></div><span>01 / DIE ERSTE FINSTERNIS</span></aside>
      <footer class="menu-footer"><span>EIN LEBEN. UNZÄHLIGE MÖGLICHKEITEN.</span><div><span>~ 12 MINUTEN</span><i></i><span>5 WAFFEN</span><i></i><span>KEIN ENTKOMMEN?</span></div><span class="save-status">Fortschritt wird lokal gespeichert</span></footer>`;
  }
  private dialog(title:string,subtitle:string,content:string){
    this.root.querySelector('.dialog-layer')?.remove();
    this.root.insertAdjacentHTML('beforeend',`<div class="dialog-layer"><section class="dialog" role="dialog" aria-modal="true" aria-label="${title}"><button class="close" data-action="close-dialog" aria-label="Schließen">×</button><span class="eyebrow">ECLIPSE SURVIVOR</span><h2>${title}</h2><p class="dialog-sub">${subtitle}</p>${content}<button class="secondary full" data-action="close-dialog">Zurück</button></section></div>`);
    this.root.querySelector<HTMLButtonElement>('.dialog button')?.focus();
  }
  settings(){
    const s=this.save.settings;
    this.dialog('Einstellungen','Passe deine Reise durch die Finsternis an.',`<div class="setting"><label for="volume">Lautstärke</label><span id="volume-value">${Math.round(s.volume*100)} %</span><input id="volume" type="range" min="0" max="1" step=".01" value="${s.volume}" data-setting="volume"></div>${(['shake','numbers','particles'] as const).map((key,i)=>`<label class="toggle-row"><span>${['Bildschirmerschütterung','Schadenszahlen','Partikeleffekte'][i]}</span><input type="checkbox" data-setting="${key}" ${s[key]?'checked':''}><span class="toggle"></span></label>`).join('')}<p class="muted settings-note">Eigene synthetische Klänge und ein leiser dunkler Grundton. Kein Audio-Download erforderlich.</p>`);
  }
  controls(){this.dialog('Die Nacht überleben','Bewege dich. Sammle Seelen. Lass deine Waffen sprechen.',`<div class="control-row"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> / Pfeiltasten</span><strong>Bewegen</strong></div><div class="control-row"><span><kbd>LEERTASTE</kbd></span><strong>Schattenschritt</strong></div><div class="control-row"><span><kbd>ESC</kbd> / <kbd>P</kbd></span><strong>Pause</strong></div><div class="control-row"><span><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd></span><strong>Upgrade wählen</strong></div><div class="guide"><p><b>Deine Waffen greifen automatisch an.</b> Grüne Kristalle geben Erfahrung. Bei jedem Levelaufstieg wählst du eine Verbesserung und heilst 5 LP.</p><p><b>Schattenschritt:</b> Alle 8 Sekunden ein unverwundbarer Sprint mit einer Schadenswelle am Startpunkt.</p><p><b>Die Finsternis:</b> Alle 90 Sekunden verstärkt sie für 20 Sekunden deine Schattenklinge und deinen Schattenschritt. Gegner werden schneller.</p><p><b>Der Entthronte erscheint nach 11 Minuten.</b> Besiege ihn, um den Riss zu versiegeln. Meide seine markierten Einschläge und Geschosse.</p></div>`);}
  stats(){const s=this.save.stats;this.dialog('Deine Chronik','Jede Nacht hinterlässt eine Spur.',`<div class="stats-grid"><div><strong>${s.runs}</strong><span>Durchläufe</span></div><div><strong>${s.wins}</strong><span>Versiegelte Risse</span></div><div><strong>${s.kills.toLocaleString('de-DE')}</strong><span>Besiegte Gegner</span></div><div><strong>${formatTime(s.bestTime)}</strong><span>Längste Überlebenszeit</span></div><div><strong>${s.bestLevel}</strong><span>Höchstes Level</span></div></div>`);}
  startHud(){
    this.view='playing';this.root.className='game-ui';this.root.innerHTML=`<div class="hud-top"><div class="vitals"><div class="vitals-label"><span>SHADOW KNIGHT</span><strong id="hp-text"></strong></div><div class="hp-track"><div id="hp-bar"></div></div><div class="level-row"><span id="level-text"></span><div class="xp-track"><div id="xp-bar"></div></div><span id="xp-text"></span></div></div><div class="run-clock"><span id="phase-name">DAS ZERBROCHENE KLOSTER</span><strong id="timer">00:00</strong><span id="phase-timer"></span></div><div class="run-count"><span>GEFALLENE</span><strong id="kills">0</strong><button data-action="pause" aria-label="Spiel pausieren">Ⅱ <span>ESC</span></button></div></div><div id="boss-hud" class="boss-hud" hidden><span>DER ENTTHRONTE</span><div><i id="boss-bar"></i></div></div><div class="hud-bottom"><div><span class="small-label">DEIN ARSENAL</span><div id="weapons" class="weapon-slots"></div></div><div class="dash-panel"><div class="dash-icon">${icon('speed')}</div><div><span>SCHATTENSCHRITT</span><div class="dash-track"><i id="dash-bar"></i></div><small id="dash-text">LEERTASTE · BEREIT</small></div></div></div><div id="toast" class="toast" role="status"></div><div id="overlay"></div>`;
    this.hud=this.root;this.lastHud=0;
  }
  update(e:Engine,force=false){
    if(!this.hud||!this.root.querySelector('#timer'))return;
    const now=performance.now();if(!force&&now-this.lastHud<90)return;this.lastHud=now;
    const set=(id:string,text:string)=>{const node=document.getElementById(id);if(node&&node.textContent!==text)node.textContent=text;};
    const width=(id:string,value:number)=>{const node=document.getElementById(id);if(node)node.style.width=`${Math.max(0,Math.min(100,value))}%`;};
    set('hp-text',`${Math.ceil(e.player.hp)} / ${e.player.maxHp}`);width('hp-bar',e.player.hp/e.player.maxHp*100);
    set('level-text',`LV. ${e.level}`);set('xp-text',`${e.xp}/${xpForLevel(e.level)}`);width('xp-bar',e.xp/xpForLevel(e.level)*100);
    set('timer',formatTime(e.time));set('kills',String(e.kills));set('phase-name',e.bossSpawned?'VERSIEGLE DEN RISS':e.eclipse?'DIE FINSTERNIS IST HIER':'DAS ZERBROCHENE KLOSTER');
    set('phase-timer',e.bossSpawned?'Besiege den Entthronten':e.eclipse?`Schatten verstärkt · ${Math.ceil(90-e.time%90)} s`:`Finsternis in ${Math.ceil(70-e.time%90)} s`);
    this.root.classList.toggle('eclipse',e.eclipse);
    width('dash-bar',(1-e.player.dashCooldown/RULES.dashCooldown)*100);set('dash-text',e.player.dashCooldown>0?`${e.player.dashCooldown.toFixed(1)} s · LÄDT AUF`:'LEERTASTE · BEREIT');
    const weapons=document.getElementById('weapons')!,weaponKey=JSON.stringify(e.build.weapons);
    if(weapons.dataset.build!==weaponKey){weapons.dataset.build=weaponKey;weapons.innerHTML=WEAPON_IDS.map(id=>`<div class="weapon-slot ${e.build.weapons[id]?'equipped':'empty'}" title="${WEAPONS[id].name}${e.build.weapons[id]?` · Stufe ${e.build.weapons[id]}`:' · noch nicht freigeschaltet'}">${icon(id)}<span>${e.build.weapons[id]||'—'}</span></div>`).join('');}
    const boss=e.boss,bossHud=document.getElementById('boss-hud')!;bossHud.hidden=!boss;if(boss)width('boss-bar',boss.hp/boss.maxHp*100);
  }
  overlay(e:Engine){
    const host=document.getElementById('overlay');if(!host)return;
    this.view=e.status;
    if(e.status==='playing'){host.innerHTML='';return;}
    if(e.status==='paused')host.innerHTML=`<div class="overlay-backdrop"><section class="pause-card"><span class="eyebrow">EIN MOMENT DER STILLE</span><h2>Die Nacht wartet.</h2><p>Atme durch. Dein Kampf ist noch nicht vorbei.</p><button class="primary full" data-action="resume">Weiterkämpfen</button><button class="secondary full" data-action="settings">Einstellungen</button><button class="text-button full" data-action="menu">Durchlauf beenden & Hauptmenü</button><span class="muted">Dieser Durchlauf wird als beendet gespeichert.</span></section></div>`;
    if(e.status==='upgrade')host.innerHTML=`<div class="overlay-backdrop upgrade-backdrop"><section class="upgrade-panel"><span class="eyebrow">LEVEL ${e.level} ERREICHT</span><h2>Die Schatten schenken Macht.</h2><p>Wähle dein Vermächtnis. <span class="muted">+5 LP wiederhergestellt</span></p><div class="upgrade-cards">${e.offers.map((offer,index)=>{
      const weapon=offer.id in WEAPONS, info=weapon?WEAPONS[offer.id as WeaponId]:PASSIVES[offer.id as PassiveId],lv=weapon?e.build.weapons[offer.id as WeaponId]:e.build.passives[offer.id as PassiveId];
      const name=offer.recovery?({heal:'Zweiter Atem',vitality:'Zähes Erbe',dash:'Schattenreserve'}[offer.recovery]):info.name;
      return `<button class="upgrade-card ${offer.rarity}" data-action="upgrade" data-index="${index}" style="--accent:${info.color}"><span class="rarity">${offer.rarity==='epic'?'EPISCH':offer.rarity==='rare'?'SELTEN':'GEWÖHNLICH'}<kbd>${index+1}</kbd></span><div class="upgrade-icon">${icon(offer.id)}</div><span class="card-type">${offer.recovery?'ERHOLUNG':weapon?(lv?'WAFFENVERBESSERUNG':'NEUE WAFFE'):'PASSIVE FÄHIGKEIT'}</span><h3>${name}</h3><span class="card-level">${offer.recovery?'SOFORTIGER EFFEKT':`STUFE ${Math.min(weapon?6:5,lv+1)} ${lv===0?'· FREISCHALTEN':''}`}</span><p>${upgradeDescription(offer,e.build)}</p><div class="card-footer">${offer.bonus?`Zusätzlich +${offer.bonus} LP Heilung`:offer.recovery?'Ein letzter Funke Hoffnung.':'Deine Macht wächst.'}<span>Wählen →</span></div></button>`;
    }).join('')}</div><span class="muted">Deine Waffen greifen automatisch an. Kombiniere ihre Stärken.</span></section></div>`;
    if(e.status==='dead'||e.status==='won')host.innerHTML=`<div class="overlay-backdrop"><section class="result-card ${e.status==='won'?'victory':''}"><img class="result-emblem" src="assets/icon.png" alt=""><span class="eyebrow">${e.status==='won'?'DER RISS IST VERSIEGELT':'DIE NACHT FORDERT IHREN PREIS'}</span><h2>${e.status==='won'?'Ein neuer Morgen.':'Im Schatten gefallen.'}</h2><p>${e.status==='won'?'Der Entthronte ist besiegt. Diesmal hat das Licht gewonnen.':'Die Finsternis erinnert sich. Deine nächste Geschichte wartet.'}</p><div class="result-stats"><div><strong>${formatTime(e.time)}</strong><span>Überlebt</span></div><div><strong>${e.kills}</strong><span>Besiegt</span></div><div><strong>${e.level}</strong><span>Level</span></div></div><span class="small-label">DEIN VERMÄCHTNIS</span><div class="result-weapons">${WEAPON_IDS.filter(id=>e.build.weapons[id]).map(id=>`<div title="${WEAPONS[id].name}">${icon(id)}<span>${WEAPONS[id].name}<small>STUFE ${e.build.weapons[id]}</small></span></div>`).join('')}</div><button class="primary full" data-action="start">${e.status==='won'?'Noch einmal in die Nacht':'Erneut herausfordern'} <span>→</span></button><button class="text-button full" data-action="menu">Zum Hauptmenü</button></section></div>`;
    host.querySelector<HTMLButtonElement>('button')?.focus();
  }
  toast(message:string){const node=document.getElementById('toast');if(!node)return;clearTimeout(this.toastTimeout);node.textContent=message;node.classList.add('visible');this.toastTimeout=setTimeout(()=>node.classList.remove('visible'),3500);}
}
