import {PASSIVE_IDS,PASSIVES,WEAPON_IDS,WEAPONS,RULES,MILESTONES,type UpgradeId,type WeaponId,type PassiveId,weaponStats} from './config';
import type {Random} from './random';
import {defaultRunConfig,type RunConfig} from './meta';
export interface Build {weapons:Record<WeaponId,number>;passives:Record<PassiveId,number>}
export interface Upgrade {id:UpgradeId;rarity:'common'|'rare'|'epic';bonus:number;recovery?:'heal'|'vitality'|'power'}
export const initialBuild=(start:WeaponId='longsword'):Build=>({weapons:Object.fromEntries(WEAPON_IDS.map(id=>[id,id===start?1:0])) as Record<WeaponId,number>,passives:Object.fromEntries(PASSIVE_IDS.map(id=>[id,0])) as Record<PassiveId,number>});
export function choices(build:Build,rng:Random,config:RunConfig=defaultRunConfig(),luck=0):Upgrade[]{
 const nw=Object.values(build.weapons).filter(Boolean).length,np=Object.values(build.passives).filter(Boolean).length;
 const pool:UpgradeId[]=[...config.weapons.filter(id=>build.weapons[id]<RULES.weaponMax&&(build.weapons[id]>0||nw<RULES.weaponSlots)),...config.passives.filter(id=>build.passives[id]<RULES.passiveMax&&(build.passives[id]>0||np<RULES.passiveSlots))];
 const result:Upgrade[]=[];
 while(pool.length&&result.length<3){const id=pool.splice(Math.floor(rng.next()*pool.length),1)[0],roll=rng.next(),rarity=roll<Math.min(.25,.08+luck)?'epic':roll<Math.min(.65,.3+luck)?'rare':'common';result.push({id,rarity,bonus:rarity==='epic'?2:rarity==='rare'?1:0});}
 for(const [id,recovery] of [['power','power'],['vitality','vitality'],['regen','heal']] as const){if(result.length===3)break;result.push({id,rarity:'common',bonus:0,recovery});}return result;
}
export function upgradeDescription(u:Upgrade,b:Build):string {
 if(u.recovery)return{heal:'Sofort 20 LP heilen.',vitality:'Run-Meisterschaft: +4 maximale LP und +4 LP Heilung.',power:'Run-Meisterschaft: dauerhaft in dieser Runde +1 % Schaden.'}[u.recovery];
 if(u.id in WEAPONS){const id=u.id as WeaponId,lv=b.weapons[id],s=weaponStats(id,lv+1);return `${WEAPONS[id].subtitle}. ${Math.round(s.damage)} Basis-ATK · ${s.cooldown.toFixed(2)} s · ${Math.round(s.range)} Reichweite. ${MILESTONES[WEAPONS[id].kind]}`;}
 return PASSIVES[u.id as PassiveId].description;
}
