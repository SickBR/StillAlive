# Qualitätssicherung – Endless Edition 2.0

Stand: 3. Oktober 2026. Berichte ohne `v2` im Namen gehören zur historischen Fassung. Kein Anspruch auf perfektes Balancing.

## Technische Prüfungen

- TypeScript-Prüfung erfolgreich, Produktionsbuild erfolgreich.
- 127 automatisierte Kernprüfungen: alle 26 Waffen jeweils auf Stufe 1/4/8/12; zwölf/acht Stufen und Slotgrenzen; Klassenwerte; sämtliche Passives und Meisterschaften; DEF, Krit, Zustände, begrenzte Heilung, Proc-Grenze, Orbitkontakte und Projektilstrecken; Levelkarten und späte Meisterschaft; Pause, Bewegung, Dash, Kontakt, Tod, freiwilliges Ende; alle drei wiederkehrenden Bosse ohne gegnerische Geschosse; Käufe und Obergrenzen; Migration, ungültige Speicherfelder, gesperrter Speicher, offene Karten beim Fortsetzen, identische Folgesimulation und keine doppelte Ressourcen-Gutschrift. Vollständiger Testbericht: reports/core-tests-v2.txt.
- Chromium: alle Verwaltungsmenüs, Einstellungen, Klassenwahl, Vorlagen ändern/kopieren, Shop-/Meisterschafts-/Grundwertkäufe, Schwierigkeitssperren, echte Tastaturbewegung/Dash, Pause, Speichern → Neuladen → Fortsetzen, Levelkarten, Bosswarnung/Belohnung, fortgesetztes Endless-Spiel, Tod, Beenden und Neustarts geprüft. Keine JavaScript-Fehler oder fehlenden Ressourcen. Siehe reports/browser-v2.json und reports/screenshots/v2-*.png.
- Produktionsfassung: Start, ca. 15 Sekunden reale Tastatureingaben, Kartenwahl und Pause ohne Entwicklungszugriff. QA-Hook fehlt wie vorgesehen, keine externen Ressourcenanfragen, keine JavaScript-Fehler. Siehe reports/production-v2.json.

Späte Zustände, hohe Shopwährungen und Lastszenarien werden im Browser teilweise ausdrücklich über den nur in Entwicklung vorhandenen QA-Zugriff gesetzt. Das ist keine Behauptung, diese Ressourcen seien regulär erspielt worden.

## Wiederholbare Kampfsimulationen

18 neue Profil-Läufe, drei Klassen, je drei Seeds, zwei Prioritäten für die Kartenwahl. Keine zusätzlichen Lebenspunkte, kostenlose Kaufwaffen, permanenten Boni oder Unverwundbarkeit. 20 Simulationsschritte pro Sekunde, höchstens 30 Minuten je Lauf; fortlaufende Kreisbewegung, begrenztes Einsammeln naher Kristalle, Ausweichen bei Gefahr. Die Botstrategie ist für Fernkampf und komplexe Formationen nicht optimal.

| Kartenpriorität | Klasse | Seed | Zeit | Ergebnis | Level | Kills | Bosse | Gold |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Universal-Priorität | warrior | 12 | 30:00 | Zeitgrenze erreicht | 16 | 217 | 4 | 330 |
| Universal-Priorität | warrior | 71 | 30:00 | Zeitgrenze erreicht | 12 | 186 | 3 | 245 |
| Universal-Priorität | warrior | 313 | 30:00 | Zeitgrenze erreicht | 14 | 180 | 4 | 323 |
| Universal-Priorität | mage | 12 | 02:13 | Niederlage | 11 | 219 | 0 | 72 |
| Universal-Priorität | mage | 71 | 01:43 | Niederlage | 10 | 178 | 0 | 58 |
| Universal-Priorität | mage | 313 | 04:12 | Niederlage | 16 | 503 | 0 | 159 |
| Universal-Priorität | archer | 12 | 01:49 | Niederlage | 10 | 188 | 0 | 61 |
| Universal-Priorität | archer | 71 | 03:51 | Niederlage | 13 | 366 | 0 | 121 |
| Universal-Priorität | archer | 313 | 05:09 | Niederlage | 19 | 719 | 1 | 304 |
| Klassenwaffen-Priorität | warrior | 12 | 06:36 | Niederlage | 18 | 666 | 1 | 269 |
| Klassenwaffen-Priorität | warrior | 71 | 25:01 | Niederlage | 25 | 796 | 4 | 562 |
| Klassenwaffen-Priorität | warrior | 313 | 06:13 | Niederlage | 17 | 502 | 0 | 158 |
| Klassenwaffen-Priorität | mage | 12 | 01:41 | Niederlage | 10 | 212 | 0 | 65 |
| Klassenwaffen-Priorität | mage | 71 | 01:29 | Niederlage | 9 | 196 | 0 | 63 |
| Klassenwaffen-Priorität | mage | 313 | 02:45 | Niederlage | 15 | 427 | 0 | 139 |
| Klassenwaffen-Priorität | archer | 12 | 01:34 | Niederlage | 10 | 228 | 0 | 73 |
| Klassenwaffen-Priorität | archer | 71 | 01:37 | Niederlage | 10 | 262 | 0 | 89 |
| Klassenwaffen-Priorität | archer | 313 | 01:50 | Niederlage | 13 | 358 | 0 | 133 |

**Befund:** Drei Läufe erreichen die 30-Minuten-Grenze, alle mit Krieger/Universal-Priorität. Die anderen Läufe enden vorher. Der Magier besiegt in diesen Szenarien keinen Boss; ein Jägerlauf besiegt einen. Das zeigt eine relevante Klassen-/Build-Asymmetrie und begründet weiteres Playtesting. Es sind keine menschlichen Gewinnraten und kein Beleg, dass alle Klassen ähnlich leicht sind.

Im Verlauf korrigiert: zu viele gleichzeitige frühe Hetzer, ungebremster früher Gegnerstau, Goldfarmen durch Beschwörer, unzuverlässige Orbitkontakte zwischen den Angriffstakten, schwache Feuerstab-Flächenwirkung und fehlender anfänglicher Pfeildurchschlag. Aktuelle Resultate werden trotz verbleibender Unterschiede vollständig ausgewiesen.

Reproduktion: `npm run simulate` für Klassenwaffen-Priorität; `npm run simulate -- --universal` für Universal-Priorität. Daten: reports/simulation-native-v2.json und reports/simulation-v2.json.

## Drei Stunden pro Klasse: Stabilität, nicht legitimes Überleben

Drei vollständige Läufe mit je 10.800 Simulationssekunden bei 20 Hz. Alle benutzen bereits ausgebaute Klassenwaffen/Passives/Meisterschaften und absichtlich künstliche Lebenspunkte/Unverwundbarkeit. Diese Läufe prüfen endlose Wellen, Effekte, Obergrenzen, gültige Zahlen und Speichersnapshots. Sie sind **kein Balancing-Ergebnis**.

| Klasse | Spielzeit | Max. Gegner | Max. Geschosse | Max. Beute | Geprüfte Checkpoints |
| --- | --- | --- | --- | --- | --- |
| warrior | 180:00 | 300 | 0 | 185 | 18 |
| mage | 180:00 | 122 | 45 | 380 | 18 |
| archer | 180:00 | 126 | 138 | 380 | 18 |

Kein Abbruch oder ungültiger Zustand. Insgesamt 54 Snapshots erfolgreich wiederherstellbar. Zusätzlich werden Boss-LP, Schaden und Belohnungen für alle fünf Schwierigkeiten ausgewertet. Siehe reports/endurance-v2.json. Reproduktion: `npm run test:endurance`.

## Browserleistung und Speichergrenzen

Chromium mit SwiftShader-Software-Rendering, kein Hardware-GPU-Benchmark. Lastaufbau: 300 Gegner und acht ausgebaute Waffen. Gemessen wurden ungefähr 50 ms Median und 50.1 ms am 95. Perzentil pro Frame. Das entspricht unter dieser Last etwa 20 FPS, also keinem gesicherten 60-FPS-Ziel. Die Aufnahme lief während weiterer lokaler Prüfungen; Zeitwerte sind nur ein grober Lastindikator.

Darstellungsobjekte nach fünf Neustarts: 506, 506, 506, 506, 506. Kein Wachstum in diesem Test. Objektpools, 300 Gegner, 380 Beuteobjekte, 280 dargestellte Geschosse, 180 Effekte und 55 Schadenslabels begrenzen die Darstellung. Geschoss-Darstellungslimits verändern den simulierten Schaden nicht. Kein mehrstündiger Browser-Heap-Test, keine breite GPU-/Firefox-/Safari-Matrix.

## Verbleibende Designgrenzen

- Magier/Jäger-Einstieg, Verhalten gegen Formationen, frühe Upgrade-Auswahl und Klassenverhältnis brauchen gezieltes menschliches Playtesting.
- Sehr lange Runden und die fünf Schwierigkeitsstufen sind technisch vorhanden; 2–3 Stunden legitimes, unterhaltsames Überleben ist kein belegtes Balanceversprechen.
- Die fünf Umgebungen variieren Boden, Palette und Dekoration; gemeinsame Arenageometrie, keine fünf separat entworfenen Karten.
- Wirtschaft und Talentfortschritt sind begrenzt, aber noch nicht durch viele menschliche Spielsitzungen bewertet.
- Einfacher Offline-Speicher; keine Cloud-/Mehrtab-Synchronisation. Bei abruptem Prozessende sind bis zu 15 Spielsekunden seit dem letzten erfolgreichen Checkpoint gefährdet.

## Start

`npm install`, dann `npm run dev`. Produktionsfassung: `npm run build`, dann `npm run preview`. Browserprüfungen benötigen laufenden Server und lokal vorhandenes Chromium oder `CHROME_PATH`. Alle Spielressourcen liegen lokal im Projekt.
